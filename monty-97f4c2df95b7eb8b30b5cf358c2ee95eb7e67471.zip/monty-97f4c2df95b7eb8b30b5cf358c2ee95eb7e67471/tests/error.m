push 0 Push 0 onto the stack
push 1 Push 1 onto the stack

push 2
  push 3
                   pall    


                           
push 4

    push 5    
      push    6        

pall This is the end of our program. Monty is awesome!$
sjfklasj
